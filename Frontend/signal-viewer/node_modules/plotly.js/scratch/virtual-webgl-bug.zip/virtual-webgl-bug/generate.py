import asyncio
import json
import os

import kaleido
from kaleido import PageGenerator
import plotly.io as pio

# Uncomment for additional Kaleido logging output
# import logging
# logging.basicConfig(level=logging.DEBUG)

PLOTLY_JS_PATH = "js/plotly-3.0.1.min.js"
VIRTUAL_WEBGL_PATH = "js/virtual-webgl.js"
PLOTLY_WITH_VIRTUAL_WEBGL_PATH = "js/plotly-with-virtual-webgl.js"

PLOTLY_JS_BAD_PATH = "js/plotly-bad.js"

MOCK_DIR = "mocks"
IMG_DIR = "images"


async def generate_images(use_virtual_webgl, approach="separate-script"):
    # If using virtual WebGL, set the plotly.js path to the file which contains
    # both Plotly.js and the virtual WebGL code.
    # Otherwise, set it to the standard Plotly.js file.
    if use_virtual_webgl:
        if approach == "separate-script":
            page = PageGenerator(
                plotly=os.path.abspath(PLOTLY_JS_PATH),
                others=[os.path.abspath(VIRTUAL_WEBGL_PATH)]
            )
        elif approach == "concatenate":
            page = PageGenerator(plotly=os.path.abspath(PLOTLY_WITH_VIRTUAL_WEBGL_PATH))
    else:
        page = PageGenerator(plotly=os.path.abspath(PLOTLY_JS_PATH))

    # For each mock .json file in the mocks directory, generate an image
    async with kaleido.Kaleido(n=1, page_generator=page) as k:
        for mock_filename in os.listdir(MOCK_DIR):
            if mock_filename.endswith(".json"):
                mock_path = os.path.join(MOCK_DIR, mock_filename)
                if use_virtual_webgl:
                        output_suffix = "-virtual-webgl"
                else:
                    output_suffix = ""
                output_filename = (
                    mock_filename.replace(".json", "") + output_suffix + ".png"
                )
                output_path = os.path.join(IMG_DIR, output_filename)

                if os.path.exists(output_path):
                    print(f"Image already exists: {output_path}")
                    continue

                # Load the mock data
                with open(mock_path, "r") as f:
                    fig = json.load(f)

                # Apply same modifications done in Plotly.js image test pipeline
                width = 700
                height = 500
                if "layout" in fig:
                    layout = fig["layout"]
                    if "autosize" not in layout or layout["autosize"] != True:
                        if "width" in layout:
                            width = layout["width"]
                        if "height" in layout:
                            height = layout["height"]

                print(f"Generating {output_path} ...")
                # pio.write_image(fig, output_path, validate=False)
                img_data = await k.calc_fig(
                    fig,
                    path=None,
                    opts=dict(
                        format="png",
                        width=width,
                        height=height,
                    ),
                )
                with open(output_path, "wb") as f:
                    f.write(img_data)

    print("Done.")


def prep_js_files():
    # Concatenate "js/plotly.min.js" and "js/virtual-webgl.js"
    # into "js/plotly-with-virtual-webgl.js"
    with open(VIRTUAL_WEBGL_PATH, "r") as f:
        virtual_webgl_content = f.read()
    with open(PLOTLY_JS_PATH, "r") as f:
        plotly_content = f.read()
    with open(PLOTLY_WITH_VIRTUAL_WEBGL_PATH, "w") as f:
        f.write(virtual_webgl_content + "\n" + plotly_content)
    print("Finished preparing js files.")


if __name__ == "__main__":
    prep_js_files()

    asyncio.run(generate_images(use_virtual_webgl=False))
    asyncio.run(generate_images(use_virtual_webgl=True))
    # Uncomment the following line (and comment the one above) to generate images with 
    # the concatenated script This is the approach used in the Plotly.js image test pipeline, 
    # but seems to produce the same results as passing a separate virtual WebGL script.
    # asyncio.run(generate_images(use_virtual_webgl=True, approach="concatenate"))
